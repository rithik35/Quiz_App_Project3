package com.example.android.quiiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int marks;
    Button btn;
    CheckBox q_1_1,q_1_3,q_1_2,q_1_4;
    RadioButton q_2_1,q_2_2,q_2_3,q_2_4,q_4_1,q_4_2,q_4_3,q_4_4,q_5_1,q_5_2,q_5_3,q_5_4;
    EditText q_3_1;
    String a="tiger";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Submit(View view) {
         q_1_1 = (CheckBox) findViewById(R.id.q_1_1);
         q_1_3 = (CheckBox) findViewById(R.id.q_1_3);
         q_1_2 = (CheckBox) findViewById(R.id.q_1_2);
         q_1_4 = (CheckBox) findViewById(R.id.q_1_4);
         q_2_1 = (RadioButton) findViewById(R.id.q_2_1);
         q_2_2 = (RadioButton) findViewById(R.id.q_2_2);
         q_2_3 = (RadioButton) findViewById(R.id.q_2_3);
         q_2_4 = (RadioButton) findViewById(R.id.q_2_4);
         q_3_1 = (EditText) findViewById(R.id.q_3_1);
         q_4_1 = (RadioButton) findViewById(R.id.q_4_1);
         q_4_2 = (RadioButton) findViewById(R.id.q_4_2);
         q_4_3 = (RadioButton) findViewById(R.id.q_4_3);
         q_4_4 = (RadioButton) findViewById(R.id.q_4_4);
         q_5_1 = (RadioButton) findViewById(R.id.q_5_1);
         q_5_2 = (RadioButton) findViewById(R.id.q_5_2);
         q_5_3 = (RadioButton) findViewById(R.id.q_5_3);
         q_5_4 = (RadioButton) findViewById(R.id.q_5_4);
         String q_3_ans = q_3_1.getText().toString().toLowerCase();

         //question_1 condition

         if ( q_1_1.isChecked() && !q_1_2.isChecked() && q_1_3.isChecked() && !q_1_4.isChecked()) {
             marks = marks + 1;
         }
        else {
             marks = marks + 0;
         }

        //question_2 condition

        if (q_2_4.isChecked()) {
            marks = marks + 1;
        }
        else {
            marks = marks + 0;
        }

        //question_3 condition

        if (q_3_ans.equals(a)) {
            marks = marks + 1;
        }
        else {
            marks = marks + 0;
        }

        //question_4 condition

        if (q_4_2.isChecked()) {
            marks = marks + 1;
        }
        else {
            marks = marks + 0;
        }

        //question_5 condition

        if (q_5_4.isChecked()) {
            marks = marks + 1;
        }
        else {
            marks = marks + 0;
        }

        if(marks == 5) {
            Toast.makeText(getApplicationContext(), "score:" + marks +" -Hurrah! All correct", Toast.LENGTH_SHORT).show();
        }
        else if (marks==4) {
            Toast.makeText(getApplicationContext(), "score:" + marks +" -Well Done!", Toast.LENGTH_SHORT).show();
        }

        else if(marks==3) {
            Toast.makeText(getApplicationContext(), "score:" + marks +" -Good try! Better luck next time", Toast.LENGTH_SHORT).show();
        }

        else if (marks==2) {
            Toast.makeText(getApplicationContext(), "score:" + marks +" -congo! need more practice", Toast.LENGTH_SHORT).show();
        }

        else if (marks==1) {
            Toast.makeText(getApplicationContext(), "score:" + marks +" -better luck next time", Toast.LENGTH_SHORT).show();
        }

        else {
            Toast.makeText(getApplicationContext(), "score:" + marks +" -Oops! it is a DUCK", Toast.LENGTH_SHORT).show();
        }

        btn=(Button)findViewById(R.id.submit);
        btn.setEnabled(false);

    }

    public void Reset(View view)
    {
        btn=(Button)findViewById(R.id.submit);
        btn.setEnabled(true);
        marks=0;
        q_1_1.setChecked(false);
        q_1_2.setChecked(false);
        q_1_3.setChecked(false);
        q_1_4.setChecked(false);
        q_2_1.setChecked(false);
        q_2_2.setChecked(false);
        q_2_3.setChecked(false);
        q_2_4.setChecked(false);
        q_4_1.setChecked(false);
        q_4_2.setChecked(false);
        q_4_3.setChecked(false);
        q_4_4.setChecked(false);
        q_5_1.setChecked(false);
        q_5_2.setChecked(false);
        q_5_4.setChecked(false);
        q_5_3.setChecked(false);
        q_3_1.setText(null);

    }
}



